<?php

require_once("models/Model.php");

use FW\Foundation\Model;

class DefaultModel extends Model
{
	public function process($values)
	{
		return $values;
	}
}
