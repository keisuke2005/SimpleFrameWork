<?php

require_once("models/Model.php");

class DefaultModel extends Model
{
	public function process($values)
	{
		return $values;
	}
}

