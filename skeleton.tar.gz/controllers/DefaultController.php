<?php

require_once("controllers/BasicController.php");
require_once("utils/Session.php");
require_once("traits/CheckSession.php");
require_once(__DIR__."/../configs/Constants.php");

use FW\Foundation\BasicController;
use FW\Library\Session;
use FW\Library\Authenticatable;
use FW\Library\CheckSession;

class DefaultController extends BasicController implements Authenticatable
{
	use CheckSession;

	protected function execute(): void
	{
		$this->check_authenticated(Constants::LOGIN_URL,Constants::LOGINED_URL);

		parent::execute();
	}

	public function is_auth_required()
	{
		return false;
	}

	public function get_auth_key()
	{
		return "login";
	}
}
