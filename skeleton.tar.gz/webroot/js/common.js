/*
 * WebApi用関数
 */
const webapi = (url,method,data) => {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.setRequestHeader('Content-Type','application/json');
    xhr.addEventListener('load', (e) => {
      if(xhr.status === 200)
      {
        resolve(xhr.responseText);
      }
      else
      {
        reject(xhr.statusText);
      }
    });
    // パラメータがあるなしで分岐
    if(data != null)
    {
      xhr.send(JSON.stringify(data));
    }
    else
    {
      xhr.send();
    }
  })
}


/*
 * jquery依存なし、モーダル
 */
function modalFadeIn(body,execText,execClass,closeOpt)
{
  let closeFunc = "modalFadeOut(false)";
  if(closeOpt !== undefined){
    let reloadByClose = false;
    if(closeOpt.hasOwnProperty('reloadByClose')){
      reloadByClose = closeOpt.reloadByClose;
    }
    closeFunc = "modalFadeOut("+reloadByClose+")";
  }

  // モーダル外エリア
  let bg = document.createElement('div');
  bg.className = '__modal__bg';
  bg.setAttribute('onclick', closeFunc);

  // 閉じるボタン
  let close = document.createElement('button');
  close.className = '__modal__button __modal__close__btn';
  close.textContent = '閉じる';
  close.setAttribute('onclick', closeFunc);

  // ボタン配置エリア
  let buttons = document.createElement('div');
  buttons.className = '__modal__buttons';
  buttons.appendChild(close);

  if(execText !== undefined){
    let exec = document.createElement('button');
    exec.className = '__modal__button __modal__exec__btn';
    exec.classList.add(execClass);
    exec.textContent = execText;
    buttons.appendChild(exec);
  }else{
    buttons.classList.add('__modal__center');
  }
  // コンテンツエリア
  let contents = document.createElement('div');
  contents.className = '__modal__contents';
  contents.insertAdjacentHTML('afterbegin',body);
  contents.appendChild(buttons);
  // コンテンツの包むエリア
  let wrapper = document.createElement('div');
  wrapper.className = '__modal__wrapper';
  wrapper.appendChild(contents);
  // モーダルアウトライン
  let modal = document.createElement('section');
  modal.className = '__modal__area __fade__in';
  modal.appendChild(bg);
  modal.appendChild(wrapper);
  // ボディに詰め込む
  let tagbody = document.getElementsByTagName('body');
  tagbody[0].insertBefore(modal,tagbody[0].children[0]);
}
/*
 * モーダル非表示（remove）
 */
function modalFadeOut(reloadByClose){
  document.getElementsByClassName('__modal__area')[0].remove();
  if(reloadByClose){
    location.reload();
  }
}
/*
 * モーダル操作関数
 */
function modalToOneBtn()
{
  $('button.__modal__exec__btn').remove();
  $('div.__modal__buttons').addClass('__modal__center');
}
/*
 * モーダル非表示（remove）
 */
function showLoadingCircle(msg){
        if( msg == undefined ){
                msg = "";
        }
        // ローディングサークルメッセージ部分作成
        let msgtag = document.createElement('div');
        msgtag.className = 'loadingMsg';
        msgtag.textContent = msg;
        if(document.getElementById('loading') == null){
          // ローディングサークル本体作成
          let loadingtag = document.createElement('div');
          loadingtag.setAttribute('id', 'loading');
          loadingtag.appendChild(msgtag);
          // bodyに追加
          let tagbody = document.getElementsByTagName('body');
          tagbody[0].insertBefore(loadingtag,tagbody[0].children[0]);
        }
}

// ローディングサークル非表示
function hiddenLoadingCircle(){
        document.getElementById('loading').remove();
}
