<html lang="<?= $this->get_lang() ?>">
	<head>
		<?= $this->flush_tags(['common'],"HeadView.php") ?>
		<title>WelcomeView</title>
	</head>
	<body>
		<h1>Welcome !</h1>
	</body>
</html>
