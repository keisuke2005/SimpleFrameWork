<meta charaset=<?= $this->get_charaset() ?>>
<?= $this->loader("css",array("bootstrap.min.css","common.css")) ?>
<?= $this->loader("js",array("bootstrap.bundle.min.js","common.js")) ?>
<?= $this->loader("js",array("jquery-3.6.0.min.js")) ?>
