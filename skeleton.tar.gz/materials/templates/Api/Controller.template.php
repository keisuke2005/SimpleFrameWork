<?php

require_once("controllers/ApiController.php");

class ___NAME extends ApiController
{
}

