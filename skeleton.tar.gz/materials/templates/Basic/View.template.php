<?php

require_once("views/BasicView.php");

class ___NAME extends BasicView
{
	public function get_title(){return "___NAME";}
	public function output(Request $request,Value $value): Value
	{
		$this->logger()->info("Start Function");
		$body =<<<EOT
		<h1>___NAME</h1>
EOT;
		$this->logger()->info("End Function");
		return $body;
	}
}
