<?php

require_once(__DIR__."/../libs/classes/AnalysisSimplePageController.php");

class ___NAME extends AnalysisSimplePageController
{
}
