<html lang="<?= $this->get_lang() ?>">
  <head>
		<?= $this->flush_html(['common'],"HeadView.php") ?>
		<title>___NAME</title>
  </head>
	<body>
  </body>
</html>
