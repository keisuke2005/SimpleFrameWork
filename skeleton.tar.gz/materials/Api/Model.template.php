<?php

require_once("models/ApiModel.php");
require_once("components/http/Get.php");
require_once("utils/Dao.php");

class ___NAME extends ApiModel implements Get
{
	public function get(Request $request,Value $value)
	{
		$this->logger()->info("Start Function");
		$value->set_hoge("fuga");
		$this->logger()->info("End Function");
		return $value;
	}
}

