<?php

require_once("controllers/BasicController.php");

class ___NAME extends BasicController
{
}

