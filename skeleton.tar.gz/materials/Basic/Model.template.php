<?php

require_once("models/BasicModel.php");
require_once("utils/Dao.php");
require_once(__DIR__."/../configs/Constants.php");

class ___NAME extends BasicModel
{
	public function process(Request $request,Value $value)
	{
		$this->logger()->info("Start Function");
		$this->logger()->info("End Function");
		return $value;
	}
}

