<?php
class Constants {
	const ROOT_URL = "/app/to/path";
	const LOGIN_URL = "/";
	const LOGINED_URL = "";
}
?>
