<?php

class Config
{
	const LOG_PATH = "";

	const DB_TYPE = "";
	const DB_NAME = "";
	const DB_USER = "";
	const DB_PW = "";
	const DB_PORT = "";
	const DB_HOST = "";
}
