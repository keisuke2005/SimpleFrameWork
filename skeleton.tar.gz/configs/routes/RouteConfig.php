<?php
require_once("routers/Router.php");
require_once("routers/Route.php");

use FW\Routing\Router;
use FW\Routing\Route;

/**
* ルーティング定義ファイル
* 形式
* Router::push(
*		Route::define(["uri:/login"])->map(
*			["mvc:Login","con:MyBasic"],																												=> GET:/aplname/login						LoginModel::process()
*			["mth:post","mvc:Login","con:MyBasic","fnc:auth"]																		=> POST:/aplname/login					LoginModel::auth()
*		),
*		Route::define(["uri:/top"])->map(
*			["uri:/page","mvc:Top","con:MyBasic"]																								=> GET:/aplname/top							TopModel::page()
*			Route::define(["uri:/search"])->map(
*				["mth:get","pfxuri:/api","uri:/all","mvc:TopEndPoint","con:MyApi"],								=> GET:/aplname/api/search/all	TopEndPointModel::get()
*				["mth:get","pfxuri:/api","uri:/{name}","mvc:TopEndPoint","con:MyApi","fnc:user"]	=> GET:/aplname/api/search/*		TopEndPointModel::process()
*			)
*		)
* );
*/

Router::push(

);
