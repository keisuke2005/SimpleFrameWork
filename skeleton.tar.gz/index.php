<?php
require_once("routers/Router.php");

class ApplicationRouter extends Router
{
	protected function get_application_path(){return __DIR__;}
}
ApplicationRouter::routing(new ApplicationRouter());
