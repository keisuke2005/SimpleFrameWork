<?php
require_once("routers/Router.php");
require_once("core/Container.php");

use FW\Routing\Router;
use FW\Foundation\Container;

class ApplicationRouter extends Router
{
	public static function get_application_path(){return __DIR__;}
}
$container = new Container();
ApplicationRouter::routing(
	$container->get(ApplicationRouter::class)(ApplicationRouter::get_application_path())
);
